Individual Contributors
=======================

A list of people who have contributed to Spyrk in order of their first
contribution.

Format: ``Name-or-Well-known-alias <email@domain.tld> (url)``

* Axel Voitier <axel.voitier@gmail.com>
* Wojtek Siudzinski <admin@suda.pl>

Please, add yourself when you contribute!
