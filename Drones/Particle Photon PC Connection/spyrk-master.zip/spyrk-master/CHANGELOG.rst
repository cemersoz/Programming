CHANGELOG
=========

0.0.3 - ?
--------------------

- Fixed Python 3 support

0.0.2 - 30 July 2014
--------------------

- Complying to Flake8 code-style checker
- Added accessing variable value
- Added `requires_deep_update` to Device declaration
- Fixed logging in bug and updated to support `requires_deep_update` value for the device
- Added setup.py and refactored main package as Spyrk.SparkCloud

0.0.1 - 26 January 2014
-----------------------

- Initial dump of code
